import React from 'react'
import './CartMainImage.css';

const CartMainImage = () => {
  return (
    <div className='cart-header'>
        <h3>Cart</h3>
    </div>
  )
}

export default CartMainImage
