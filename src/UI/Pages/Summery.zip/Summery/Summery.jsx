import React from 'react'
import OrderSummeryTwo from '../../Components/OrderSummery/OrderSummery'

const Summery = () => {
  
  return (
    <div>
        <OrderSummeryTwo />
    </div>
  )
}

export default Summery
